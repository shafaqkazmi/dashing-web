const BaseUrl = `https://651d28df44e393af2d5943f5.mockapi.io/api/v1`;

export const Api = {
  UserName: "admin",
  Password: "123",
  Default: "/signin",
  GetUsers: `${BaseUrl}/users`,
  Login: `https://dummyjson.com/auth/login`,
};